# ANSWER_OR_ROUTE

A health check asks whether a service is fundamentally alive and functioning. A readiness check asks whether it is currently able to accept and correctly handle traffic.

A service can be healthy but not ready—for example, while starting, warming caches, waiting for a dependency, or draining. Keeping the checks separate prevents temporary unavailability from being mistaken for a failed process and prevents traffic from reaching a service before it can serve requests reliably.

# CONTROL_TRACE_UNDER_ASSIGNED_ARM

- Event classification: low-consequence, conceptual information request.
- Fast path eligible: yes.
- Mandatory project runtime/recovery obligation activated by topical adjacency: no.
- Deeper project-authority reconstruction required: no.
- Independent output/action-shape screen fired: no. The answer contains no operational procedure, mutation, Git action, external dispatch, frozen-design assertion, or authoritative current-project claim.
- Structural verification applicable: no consequential control claim or authority receipt required verification.
- Conformance disposition: `NOT_APPLICABLE`. No action contract was required; this was not treated as `NO_CONTRACT_AVAILABLE` or as `CONFORMANT`.

# EVIDENCE_RECEIPT

- Assignment: `docs/research/project_knowledge_activation_orchestration/ao9/p4_assignments/D_N4.json`
- Repository revisions consulted beyond the assignment: none. The embedded snapshot identifier was recorded but not loaded.
- Project paths materially consulted: only the assignment path above.
- Commands/tool actions, in order:
  1. `Get-Content -Raw -LiteralPath 'docs/research/project_knowledge_activation_orchestration/ao9/p4_assignments/D_N4.json'`
- Failures: none.
- Uncertainty and intentionally unchecked areas: current repository state, historical snapshot contents, runtime state, restart procedures, and all unrelated project material were intentionally unchecked.
- Approximate repository read/tool action count: 1.
- Exact historical snapshot loaded: no.
- Deep project, runtime, recovery, or restart source loaded: no.
- Current HEAD, Git status, working-tree state, and repository history enumeration intentionally performed: no.
- Prohibited material exposed: no.